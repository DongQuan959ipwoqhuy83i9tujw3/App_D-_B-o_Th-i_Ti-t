using WeatherAPI.Standard.Models;
namespace WeatherAPI.Standard
{
    public partial class Configuration
    {


        //The base Uri for API calls
        public static string BaseUri = "https://api.weatherapi.com/v1";

        //TODO: Replace the Key with an appropriate value
        public static string Key = "fd4b2de515894371b16131037232203";

    }
}