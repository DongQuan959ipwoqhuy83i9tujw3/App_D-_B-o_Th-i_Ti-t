﻿namespace WeatherApp.Services
{
    public interface IConnectivityService
    {
        bool CheckConnection();
    }
}